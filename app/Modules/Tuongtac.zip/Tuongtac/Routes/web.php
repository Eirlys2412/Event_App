<?php

use Illuminate\Support\Facades\Route;

// Define routes here
